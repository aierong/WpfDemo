﻿namespace HalconWPF.UserControl
{
    /// <summary>
    /// ClipNumberAndAngle.xaml 的交互逻辑
    /// </summary>
    public partial class ClipNumberAndAngle
    {
        public ClipNumberAndAngle()
        {
            InitializeComponent();
        }
    }
}
