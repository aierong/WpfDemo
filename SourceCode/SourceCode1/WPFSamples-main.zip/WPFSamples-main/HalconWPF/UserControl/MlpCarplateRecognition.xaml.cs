﻿namespace HalconWPF.UserControl
{
    /// <summary>
    /// MlpCarplateRecognition.xaml 的交互逻辑
    /// </summary>
    public partial class MlpCarplateRecognition
    {
        public MlpCarplateRecognition()
        {
            InitializeComponent();
        }
    }
}