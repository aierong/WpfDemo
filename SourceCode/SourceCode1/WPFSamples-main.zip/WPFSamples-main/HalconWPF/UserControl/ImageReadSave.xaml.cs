﻿namespace HalconWPF.UserControl
{
    /// <summary>
    /// ImageReadSave.xaml 的交互逻辑
    /// </summary>
    public partial class ImageReadSave
    {
        public ImageReadSave()
        {
            InitializeComponent();
        }
    }
}
