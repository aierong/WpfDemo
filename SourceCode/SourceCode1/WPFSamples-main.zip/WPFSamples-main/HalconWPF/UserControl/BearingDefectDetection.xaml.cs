﻿namespace HalconWPF.UserControl
{
    /// <summary>
    /// BearingDefectDetection.xaml 的交互逻辑
    /// </summary>
    public partial class BearingDefectDetection
    {
        public BearingDefectDetection()
        {
            InitializeComponent();
        }
    }
}
