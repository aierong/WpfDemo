﻿namespace HalconWPF.UserControl
{
    /// <summary>
    /// MlpNumberRecognition.xaml 的交互逻辑
    /// </summary>
    public partial class MlpNumberRecognition
    {
        public MlpNumberRecognition()
        {
            InitializeComponent();
        }
    }
}