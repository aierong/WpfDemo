﻿namespace HalconWPF.UserControl
{
    /// <summary>
    /// PcbDefectDetection.xaml 的交互逻辑
    /// </summary>
    public partial class PcbDefectDetection
    {
        public PcbDefectDetection()
        {
            InitializeComponent();
        }
    }
}
