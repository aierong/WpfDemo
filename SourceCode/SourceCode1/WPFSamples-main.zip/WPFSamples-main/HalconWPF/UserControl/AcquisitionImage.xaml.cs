﻿namespace HalconWPF.UserControl
{
    /// <summary>
    /// AcquisitionImage.xaml 的交互逻辑
    /// </summary>
    public partial class AcquisitionImage
    {
        public AcquisitionImage()
        {
            InitializeComponent();
        }
    }
}
