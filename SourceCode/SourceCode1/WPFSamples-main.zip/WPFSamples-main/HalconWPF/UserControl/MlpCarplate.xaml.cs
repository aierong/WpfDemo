﻿namespace HalconWPF.UserControl
{
    /// <summary>
    /// MlpCarplate.xaml 的交互逻辑
    /// </summary>
    public partial class MlpCarplate
    {
        public MlpCarplate()
        {
            InitializeComponent();
        }
    }
}