﻿namespace HalconWPF.UserControl
{
    /// <summary>
    /// MeasureTools.xaml 的交互逻辑
    /// </summary>
    public partial class MeasureTools
    {
        public MeasureTools()
        {
            InitializeComponent();
        }
    }
}