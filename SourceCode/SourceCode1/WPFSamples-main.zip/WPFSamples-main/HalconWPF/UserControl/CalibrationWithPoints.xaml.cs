﻿namespace HalconWPF.UserControl
{
    /// <summary>
    /// CalibrationWithPoints.xaml 的交互逻辑
    /// </summary>
    public partial class CalibrationWithPoints
    {
        public CalibrationWithPoints()
        {
            InitializeComponent();
        }
    }
}
