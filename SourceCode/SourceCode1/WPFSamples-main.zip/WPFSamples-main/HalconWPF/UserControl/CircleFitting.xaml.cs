﻿namespace HalconWPF.UserControl
{
    /// <summary>
    /// CircleFitting.xaml 的交互逻辑
    /// </summary>
    public partial class CircleFitting
    {
        public CircleFitting()
        {
            InitializeComponent();
        }
    }
}
