﻿namespace HalconWPF.UserControl
{
    /// <summary>
    /// TeethDetection.xaml 的交互逻辑
    /// </summary>
    public partial class TeethDetection
    {
        public TeethDetection()
        {
            InitializeComponent();
        }
    }
}
