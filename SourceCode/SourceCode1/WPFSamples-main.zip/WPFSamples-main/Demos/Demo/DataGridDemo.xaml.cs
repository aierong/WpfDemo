﻿using System.Windows.Controls;

namespace Demos.Demo
{
    /// <summary>
    /// DataGridDemo.xaml 的交互逻辑
    /// </summary>
    public partial class DataGridDemo : UserControl
    {
        public DataGridDemo()
        {
            InitializeComponent();
        }
    }
}