﻿namespace MvvmTutorials.ToolkitMessages.Models;

public record Student(string Name, string Class, string Phone);