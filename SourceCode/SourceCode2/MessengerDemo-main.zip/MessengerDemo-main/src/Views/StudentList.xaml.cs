﻿using System.Windows.Controls;

namespace MvvmTutorials.ToolkitMessages.Views
{
    public partial class StudentList : UserControl
    {
        public StudentList()
        {
            InitializeComponent();
        }
    }
}
