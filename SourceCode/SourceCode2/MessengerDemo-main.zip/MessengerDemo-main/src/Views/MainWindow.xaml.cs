﻿using System.Windows;

namespace MvvmTutorials.ToolkitMessages.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}