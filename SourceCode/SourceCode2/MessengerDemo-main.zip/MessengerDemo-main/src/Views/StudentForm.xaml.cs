﻿using System.Windows.Controls;

namespace MvvmTutorials.ToolkitMessages.Views
{
    public partial class StudentForm : UserControl
    {
        public StudentForm()
        {
            InitializeComponent();
        }
    }
}
