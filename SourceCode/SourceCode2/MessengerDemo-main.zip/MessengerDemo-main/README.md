# MessengerDemo

CommunityToolkit.Mvvm Messenger 演示代码

![Demo](demo.png)