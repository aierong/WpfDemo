﻿using System.Windows.Documents;

namespace HandyControl.Controls;

public class DrawerContainer : AdornerDecorator
{

}
