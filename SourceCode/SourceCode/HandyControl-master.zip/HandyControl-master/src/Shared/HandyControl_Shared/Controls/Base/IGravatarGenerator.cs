﻿namespace HandyControl.Controls;

public interface IGravatarGenerator
{
    object GetGravatar(string id);
}
