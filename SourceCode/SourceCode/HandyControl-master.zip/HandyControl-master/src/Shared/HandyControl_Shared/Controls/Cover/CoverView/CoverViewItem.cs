﻿namespace HandyControl.Controls;

public class CoverViewItem : HeaderedSelectableItem
{
    internal int Index { get; set; }
}
