﻿using System.Windows.Controls;

namespace HandyControl.Controls;

public class AutoCompleteTextBoxItem : ComboBoxItem
{

}
