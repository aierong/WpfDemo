﻿using System.Windows.Documents;

namespace HandyControl.Controls;

public class DialogContainer : AdornerDecorator
{

}
