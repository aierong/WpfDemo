﻿namespace HandyControlDemo.UserControl;

public partial class Login
{
    public Login()
    {
        InitializeComponent();
    }
}
