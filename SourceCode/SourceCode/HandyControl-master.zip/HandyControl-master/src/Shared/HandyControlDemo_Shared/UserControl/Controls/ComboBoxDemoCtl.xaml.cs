﻿namespace HandyControlDemo.UserControl;

public partial class ComboBoxDemoCtl
{
    public ComboBoxDemoCtl()
    {
        InitializeComponent();
    }
}
