﻿
namespace HandyControlDemo.UserControl;

public partial class ListBoxDemoCtl
{
    public ListBoxDemoCtl()
    {
        InitializeComponent();
    }
}
