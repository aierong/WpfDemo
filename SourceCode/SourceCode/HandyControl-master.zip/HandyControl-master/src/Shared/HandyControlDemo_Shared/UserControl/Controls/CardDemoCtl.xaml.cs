﻿namespace HandyControlDemo.UserControl;

public partial class CardDemoCtl
{
    public CardDemoCtl()
    {
        InitializeComponent();
    }
}
