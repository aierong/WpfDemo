﻿namespace HandyControlDemo.UserControl;

public partial class TransitioningContentControlDemoCtl
{
    public TransitioningContentControlDemoCtl()
    {
        InitializeComponent();
    }
}
