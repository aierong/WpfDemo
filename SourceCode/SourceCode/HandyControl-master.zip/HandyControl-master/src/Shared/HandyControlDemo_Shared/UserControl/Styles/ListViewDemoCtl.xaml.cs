﻿namespace HandyControlDemo.UserControl;

public partial class ListViewDemoCtl
{
    public ListViewDemoCtl()
    {
        InitializeComponent();
    }
}
