﻿namespace HandyControlDemo.UserControl;

public partial class DateTimePickerDemoCtl
{
    public DateTimePickerDemoCtl()
    {
        InitializeComponent();
    }
}
