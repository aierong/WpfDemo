﻿
namespace HandyControlDemo.UserControl;

public partial class ClockDemoCtl
{
    public ClockDemoCtl()
    {
        InitializeComponent();
    }
}
