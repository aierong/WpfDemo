﻿
namespace HandyControlDemo.UserControl;

public partial class SliderDemoCtl
{
    public SliderDemoCtl()
    {
        InitializeComponent();
    }
}
