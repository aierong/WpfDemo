﻿
namespace HandyControlDemo.UserControl;

public partial class NativeProgressBarDemoCtl
{
    public NativeProgressBarDemoCtl()
    {
        InitializeComponent();
    }
}
