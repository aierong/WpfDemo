﻿
namespace HandyControlDemo.UserControl;

public partial class TreeViewDemoCtl
{
    public TreeViewDemoCtl()
    {
        InitializeComponent();
    }
}
