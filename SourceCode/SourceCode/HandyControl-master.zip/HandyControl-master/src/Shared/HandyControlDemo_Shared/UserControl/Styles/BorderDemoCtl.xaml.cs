﻿
namespace HandyControlDemo.UserControl;

public partial class BorderDemoCtl
{
    public BorderDemoCtl()
    {
        InitializeComponent();
    }
}
