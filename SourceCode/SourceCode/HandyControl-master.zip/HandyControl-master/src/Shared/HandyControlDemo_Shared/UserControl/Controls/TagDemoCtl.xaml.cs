﻿namespace HandyControlDemo.UserControl;

public partial class TagDemoCtl
{
    public TagDemoCtl()
    {
        InitializeComponent();
    }
}
