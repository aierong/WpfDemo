﻿namespace HandyControlDemo.UserControl;

public partial class AnimationPathDemoCtl
{
    public AnimationPathDemoCtl()
    {
        InitializeComponent();
    }
}
