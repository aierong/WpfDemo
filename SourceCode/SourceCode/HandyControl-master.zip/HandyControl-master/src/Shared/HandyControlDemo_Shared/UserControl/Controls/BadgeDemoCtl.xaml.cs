﻿namespace HandyControlDemo.UserControl;

public partial class BadgeDemoCtl
{
    public BadgeDemoCtl()
    {
        InitializeComponent();
    }
}
