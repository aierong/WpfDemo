﻿namespace HandyControlDemo.UserControl;

public partial class LabelDemoCtl
{
    public LabelDemoCtl()
    {
        InitializeComponent();
    }
}
