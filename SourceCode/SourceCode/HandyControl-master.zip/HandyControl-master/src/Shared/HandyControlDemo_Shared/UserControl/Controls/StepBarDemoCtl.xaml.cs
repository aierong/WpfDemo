﻿
namespace HandyControlDemo.UserControl;

public partial class StepBarDemoCtl
{
    public StepBarDemoCtl()
    {
        InitializeComponent();
    }
}
