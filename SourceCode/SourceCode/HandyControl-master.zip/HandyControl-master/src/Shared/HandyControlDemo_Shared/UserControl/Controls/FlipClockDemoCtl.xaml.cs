﻿namespace HandyControlDemo.UserControl;

public partial class FlipClockDemoCtl
{
    public FlipClockDemoCtl()
    {
        InitializeComponent();
    }
}
