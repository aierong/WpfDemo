﻿namespace HandyControlDemo.UserControl;

public partial class WatermarkDemoCtl
{
    public WatermarkDemoCtl()
    {
        InitializeComponent();
    }
}
