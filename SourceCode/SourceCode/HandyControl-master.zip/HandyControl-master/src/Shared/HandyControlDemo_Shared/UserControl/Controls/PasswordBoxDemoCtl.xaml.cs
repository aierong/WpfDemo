﻿namespace HandyControlDemo.UserControl;

public partial class PasswordBoxDemoCtl
{
    public PasswordBoxDemoCtl()
    {
        InitializeComponent();
    }
}
