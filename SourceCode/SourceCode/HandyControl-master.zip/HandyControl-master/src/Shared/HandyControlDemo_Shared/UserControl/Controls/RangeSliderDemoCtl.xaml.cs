﻿namespace HandyControlDemo.UserControl;

public partial class RangeSliderDemoCtl
{
    public RangeSliderDemoCtl()
    {
        InitializeComponent();
    }
}
