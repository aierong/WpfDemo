﻿namespace HandyControlDemo.UserControl;

public partial class InteractiveDialog
{
    public InteractiveDialog()
    {
        InitializeComponent();
    }
}
