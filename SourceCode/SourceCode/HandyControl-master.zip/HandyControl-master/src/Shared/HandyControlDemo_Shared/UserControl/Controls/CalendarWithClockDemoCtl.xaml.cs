﻿namespace HandyControlDemo.UserControl;

public partial class CalendarWithClockDemoCtl
{
    public CalendarWithClockDemoCtl()
    {
        InitializeComponent();
    }
}
