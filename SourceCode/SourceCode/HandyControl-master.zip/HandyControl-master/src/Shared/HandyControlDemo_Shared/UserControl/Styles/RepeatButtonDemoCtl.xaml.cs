﻿namespace HandyControlDemo.UserControl;

public partial class RepeatButtonDemoCtl
{
    public RepeatButtonDemoCtl()
    {
        InitializeComponent();
    }
}
