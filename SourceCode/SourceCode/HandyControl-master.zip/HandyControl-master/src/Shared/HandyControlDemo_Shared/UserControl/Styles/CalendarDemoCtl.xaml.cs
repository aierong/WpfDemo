﻿namespace HandyControlDemo.UserControl;

public partial class CalendarDemoCtl
{
    public CalendarDemoCtl()
    {
        InitializeComponent();
    }
}
