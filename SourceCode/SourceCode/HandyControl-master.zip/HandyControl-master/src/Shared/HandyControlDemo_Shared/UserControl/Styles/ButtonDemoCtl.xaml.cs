﻿namespace HandyControlDemo.UserControl;

public partial class ButtonDemoCtl
{
    public ButtonDemoCtl()
    {
        InitializeComponent();
    }
}
