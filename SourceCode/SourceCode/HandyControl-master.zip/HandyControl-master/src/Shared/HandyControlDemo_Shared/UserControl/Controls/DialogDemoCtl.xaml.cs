﻿namespace HandyControlDemo.UserControl;

public partial class DialogDemoCtl
{
    public DialogDemoCtl()
    {
        InitializeComponent();
    }
}
