﻿namespace HandyControlDemo.UserControl;

public partial class NativePasswordBoxDemoCtl
{
    public NativePasswordBoxDemoCtl()
    {
        InitializeComponent();
    }
}
