﻿
namespace HandyControlDemo.UserControl;

public partial class CarouselDemoCtl
{
    public CarouselDemoCtl()
    {
        InitializeComponent();
    }
}
