﻿
namespace HandyControlDemo.UserControl;

public partial class ContributorsView
{
    public ContributorsView()
    {
        InitializeComponent();
    }
}
