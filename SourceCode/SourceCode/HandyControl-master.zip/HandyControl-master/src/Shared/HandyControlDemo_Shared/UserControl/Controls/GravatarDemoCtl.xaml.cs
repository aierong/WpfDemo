﻿namespace HandyControlDemo.UserControl;

public partial class GravatarDemoCtl
{
    public GravatarDemoCtl()
    {
        InitializeComponent();
    }
}
