﻿namespace HandyControlDemo.UserControl;

public partial class EffectsDemoCtl
{
    public EffectsDemoCtl()
    {
        InitializeComponent();
    }
}
