﻿namespace HandyControlDemo.UserControl;

public partial class WebsitesView
{
    public WebsitesView()
    {
        InitializeComponent();
    }
}
