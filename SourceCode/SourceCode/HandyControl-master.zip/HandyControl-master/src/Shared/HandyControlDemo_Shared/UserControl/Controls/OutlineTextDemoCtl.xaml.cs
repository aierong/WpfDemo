﻿namespace HandyControlDemo.UserControl;

public partial class OutlineTextDemoCtl
{
    public OutlineTextDemoCtl()
    {
        InitializeComponent();
    }
}
