﻿namespace HandyControlDemo.UserControl;

public partial class NativeWindowDemoCtl
{
    public NativeWindowDemoCtl()
    {
        InitializeComponent();
    }
}
