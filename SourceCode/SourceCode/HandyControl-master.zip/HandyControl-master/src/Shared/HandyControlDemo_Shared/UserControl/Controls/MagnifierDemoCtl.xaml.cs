﻿namespace HandyControlDemo.UserControl;

public partial class MagnifierDemoCtl
{
    public MagnifierDemoCtl()
    {
        InitializeComponent();
    }
}
