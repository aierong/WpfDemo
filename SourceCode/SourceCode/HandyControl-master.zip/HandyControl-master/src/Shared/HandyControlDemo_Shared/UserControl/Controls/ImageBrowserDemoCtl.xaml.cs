﻿
namespace HandyControlDemo.UserControl;

public partial class ImageBrowserDemoCtl
{
    public ImageBrowserDemoCtl()
    {
        InitializeComponent();
    }
}
