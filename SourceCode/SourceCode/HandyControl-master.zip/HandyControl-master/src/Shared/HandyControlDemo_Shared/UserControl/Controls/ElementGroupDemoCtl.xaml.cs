﻿namespace HandyControlDemo.UserControl;

public partial class ElementGroupDemoCtl
{
    public ElementGroupDemoCtl()
    {
        InitializeComponent();
    }
}
