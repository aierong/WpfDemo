﻿
namespace HandyControlDemo.UserControl;

public partial class LoadingDemoCtl
{
    public LoadingDemoCtl()
    {
        InitializeComponent();
    }
}
