﻿namespace HandyControlDemo.UserControl;

public partial class RunningBlockDemoCtl
{
    public RunningBlockDemoCtl()
    {
        InitializeComponent();
    }
}
