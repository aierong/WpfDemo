﻿namespace HandyControlDemo.UserControl;

public partial class PracticalDemo
{
    public PracticalDemo()
    {
        InitializeComponent();
    }
}
