﻿namespace HandyControlDemo.UserControl;

public partial class FloatingBlockDemoCtl
{
    public FloatingBlockDemoCtl()
    {
        InitializeComponent();
    }
}
