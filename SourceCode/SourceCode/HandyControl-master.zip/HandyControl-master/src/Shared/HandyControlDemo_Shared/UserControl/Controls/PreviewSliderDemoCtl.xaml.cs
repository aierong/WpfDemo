﻿
namespace HandyControlDemo.UserControl;

public partial class PreviewSliderDemoCtl
{
    public PreviewSliderDemoCtl()
    {
        InitializeComponent();
    }
}
