﻿namespace HandyControlDemo.UserControl;

public partial class SpriteDemoCtl
{
    public SpriteDemoCtl()
    {
        InitializeComponent();
    }
}
