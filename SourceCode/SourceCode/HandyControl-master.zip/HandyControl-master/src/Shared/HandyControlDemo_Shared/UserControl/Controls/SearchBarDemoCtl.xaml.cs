﻿namespace HandyControlDemo.UserControl;

public partial class SearchBarDemoCtl
{
    public SearchBarDemoCtl()
    {
        InitializeComponent();
    }
}
