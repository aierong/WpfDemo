﻿namespace HandyControlDemo.UserControl;

public partial class NumericUpDownDemoCtl
{
    public NumericUpDownDemoCtl()
    {
        InitializeComponent();
    }
}
