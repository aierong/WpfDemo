﻿namespace HandyControlDemo.UserControl;

public partial class RichTextBoxDemoCtl
{
    public RichTextBoxDemoCtl()
    {
        InitializeComponent();
    }
}
