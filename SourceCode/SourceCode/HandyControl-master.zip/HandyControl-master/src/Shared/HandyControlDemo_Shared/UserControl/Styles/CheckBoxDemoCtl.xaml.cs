﻿
namespace HandyControlDemo.UserControl;

public partial class CheckBoxDemoCtl
{
    public CheckBoxDemoCtl()
    {
        InitializeComponent();
    }
}
