﻿namespace HandyControlDemo.UserControl;

public partial class DrawerDemoCtl
{
    public DrawerDemoCtl()
    {
        InitializeComponent();
    }
}
