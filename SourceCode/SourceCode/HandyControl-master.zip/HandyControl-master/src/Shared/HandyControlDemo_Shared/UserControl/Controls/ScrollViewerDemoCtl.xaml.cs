﻿
namespace HandyControlDemo.UserControl;

public partial class ScrollViewerDemoCtl
{
    public ScrollViewerDemoCtl()
    {
        InitializeComponent();
    }
}
