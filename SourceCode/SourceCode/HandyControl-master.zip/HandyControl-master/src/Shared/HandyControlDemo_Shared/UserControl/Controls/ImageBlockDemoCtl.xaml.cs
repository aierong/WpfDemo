﻿namespace HandyControlDemo.UserControl;

public partial class ImageBlockDemoCtl
{
    public ImageBlockDemoCtl()
    {
        InitializeComponent();
    }
}
