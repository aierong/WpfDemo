﻿
namespace HandyControlDemo.UserControl;

public partial class GrowlDemoCtl
{
    public GrowlDemoCtl()
    {
        InitializeComponent();
    }
}
