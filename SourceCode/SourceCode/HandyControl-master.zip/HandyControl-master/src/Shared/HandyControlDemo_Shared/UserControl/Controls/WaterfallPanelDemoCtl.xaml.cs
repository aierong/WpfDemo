﻿namespace HandyControlDemo.UserControl;

public partial class WaterfallPanelDemoCtl
{
    public WaterfallPanelDemoCtl()
    {
        InitializeComponent();
    }
}
