﻿

namespace HandyControlDemo.UserControl;

public partial class ExpanderDemoCtl
{
    public ExpanderDemoCtl()
    {
        InitializeComponent();
    }
}
