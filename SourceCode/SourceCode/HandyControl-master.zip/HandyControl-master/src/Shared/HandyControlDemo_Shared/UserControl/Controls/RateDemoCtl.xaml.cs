﻿namespace HandyControlDemo.UserControl;

public partial class RateDemoCtl
{
    public RateDemoCtl()
    {
        InitializeComponent();
    }
}
