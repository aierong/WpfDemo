﻿namespace HandyControlDemo.UserControl;

public partial class BlogsView
{
    public BlogsView()
    {
        InitializeComponent();
    }
}
