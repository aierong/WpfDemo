﻿namespace HandyControlDemo.UserControl;

internal interface IFull
{

}
