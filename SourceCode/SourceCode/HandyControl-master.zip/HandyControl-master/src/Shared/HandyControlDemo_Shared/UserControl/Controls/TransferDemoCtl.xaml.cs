﻿namespace HandyControlDemo.UserControl;

public partial class TransferDemoCtl
{
    public TransferDemoCtl()
    {
        InitializeComponent();
    }
}
