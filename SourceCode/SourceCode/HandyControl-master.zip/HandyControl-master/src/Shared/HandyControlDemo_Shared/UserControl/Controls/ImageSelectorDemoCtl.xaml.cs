﻿namespace HandyControlDemo.UserControl;

public partial class ImageSelectorDemoCtl
{
    public ImageSelectorDemoCtl()
    {
        InitializeComponent();
    }
}
