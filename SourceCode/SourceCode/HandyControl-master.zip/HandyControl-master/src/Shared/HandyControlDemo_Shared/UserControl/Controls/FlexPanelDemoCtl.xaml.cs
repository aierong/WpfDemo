﻿namespace HandyControlDemo.UserControl;

public partial class FlexPanelDemoCtl : IFull
{
    public FlexPanelDemoCtl()
    {
        InitializeComponent();
    }
}
