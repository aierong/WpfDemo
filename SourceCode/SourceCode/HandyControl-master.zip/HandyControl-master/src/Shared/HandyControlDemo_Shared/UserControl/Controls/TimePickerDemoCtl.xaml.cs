﻿namespace HandyControlDemo.UserControl;

public partial class TimePickerDemoCtl
{
    public TimePickerDemoCtl()
    {
        InitializeComponent();
    }
}
