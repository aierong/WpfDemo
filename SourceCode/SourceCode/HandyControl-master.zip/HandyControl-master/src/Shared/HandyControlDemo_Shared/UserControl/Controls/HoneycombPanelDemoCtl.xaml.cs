﻿namespace HandyControlDemo.UserControl;

public partial class HoneycombPanelDemoCtl
{
    public HoneycombPanelDemoCtl()
    {
        InitializeComponent();
    }
}
