﻿namespace HandyControlDemo.UserControl;

public partial class NotificationDemoCtl
{
    public NotificationDemoCtl()
    {
        InitializeComponent();
    }
}
