﻿namespace HandyControlDemo.UserControl;

public partial class AutoCompleteTextBoxDemoCtl
{
    public AutoCompleteTextBoxDemoCtl()
    {
        InitializeComponent();
    }
}
