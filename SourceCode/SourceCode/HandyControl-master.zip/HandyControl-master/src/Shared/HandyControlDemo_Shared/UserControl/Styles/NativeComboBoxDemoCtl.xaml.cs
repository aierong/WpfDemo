﻿namespace HandyControlDemo.UserControl;

public partial class NativeComboBoxDemoCtl
{
    public NativeComboBoxDemoCtl()
    {
        InitializeComponent();
    }
}
