﻿namespace HandyControlDemo.UserControl;

public partial class AppNotification
{
    public AppNotification()
    {
        InitializeComponent();
    }
}
