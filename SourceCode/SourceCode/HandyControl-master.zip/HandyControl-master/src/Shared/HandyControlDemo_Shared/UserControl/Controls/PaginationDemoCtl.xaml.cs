﻿
namespace HandyControlDemo.UserControl;

public partial class PaginationDemoCtl
{
    public PaginationDemoCtl()
    {
        InitializeComponent();
    }
}
