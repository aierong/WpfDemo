﻿namespace HandyControlDemo.UserControl;

public partial class GroupBoxDemoCtl
{
    public GroupBoxDemoCtl()
    {
        InitializeComponent();
    }
}
