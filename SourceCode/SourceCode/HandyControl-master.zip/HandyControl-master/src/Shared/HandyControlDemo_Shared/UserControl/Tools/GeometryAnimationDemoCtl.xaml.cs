﻿namespace HandyControlDemo.UserControl;

public partial class GeometryAnimationDemoCtl
{
    public GeometryAnimationDemoCtl()
    {
        InitializeComponent();
    }
}
