﻿
namespace HandyControlDemo.UserControl;

public partial class NativeTabControlDemoCtl
{
    public NativeTabControlDemoCtl()
    {
        InitializeComponent();
    }
}
