﻿namespace HandyControlDemo.UserControl;

public partial class ChatBubbleDemoCtl
{
    public ChatBubbleDemoCtl()
    {
        InitializeComponent();
    }
}
