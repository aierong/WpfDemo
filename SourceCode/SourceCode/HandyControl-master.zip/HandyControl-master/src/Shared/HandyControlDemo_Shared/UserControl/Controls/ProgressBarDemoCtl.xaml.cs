﻿
namespace HandyControlDemo.UserControl;

public partial class ProgressBarDemoCtl
{
    public ProgressBarDemoCtl()
    {
        InitializeComponent();
    }
}
