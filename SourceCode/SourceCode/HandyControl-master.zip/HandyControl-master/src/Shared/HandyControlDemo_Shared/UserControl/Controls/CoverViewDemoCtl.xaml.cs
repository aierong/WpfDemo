﻿namespace HandyControlDemo.UserControl;

public partial class CoverViewDemoCtl
{
    public CoverViewDemoCtl()
    {
        InitializeComponent();
    }
}
