﻿namespace HandyControlDemo.UserControl;

public partial class TextBoxDemoCtl
{
    public TextBoxDemoCtl()
    {
        InitializeComponent();
    }
}
