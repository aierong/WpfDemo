﻿namespace HandyControlDemo.UserControl;

public partial class DatePickerDemoCtl
{
    public DatePickerDemoCtl()
    {
        InitializeComponent();
    }
}
