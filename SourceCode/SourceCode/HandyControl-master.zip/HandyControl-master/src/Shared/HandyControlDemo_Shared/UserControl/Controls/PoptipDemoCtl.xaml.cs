﻿namespace HandyControlDemo.UserControl;

public partial class PoptipDemoCtl
{
    public PoptipDemoCtl()
    {
        InitializeComponent();
    }
}
