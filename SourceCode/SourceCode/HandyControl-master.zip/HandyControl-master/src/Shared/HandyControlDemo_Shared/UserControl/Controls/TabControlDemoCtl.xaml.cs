﻿namespace HandyControlDemo.UserControl;

public partial class TabControlDemoCtl
{
    public TabControlDemoCtl()
    {
        InitializeComponent();
    }
}
