﻿
namespace HandyControlDemo.UserControl;

public partial class ColorPickerDemoCtl
{
    public ColorPickerDemoCtl()
    {
        InitializeComponent();
    }
}
