﻿namespace HandyControlDemo.UserControl;

public partial class CheckComboBoxDemoCtl
{
    public CheckComboBoxDemoCtl()
    {
        InitializeComponent();
    }
}
