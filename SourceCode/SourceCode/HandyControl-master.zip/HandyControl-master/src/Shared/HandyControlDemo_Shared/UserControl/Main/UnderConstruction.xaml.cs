﻿namespace HandyControlDemo.UserControl;

public partial class UnderConstruction
{
    public UnderConstruction()
    {
        InitializeComponent();
    }
}
