﻿namespace HandyControlDemo.UserControl;

public partial class DividerDemoCtl
{
    public DividerDemoCtl()
    {
        InitializeComponent();
    }
}
