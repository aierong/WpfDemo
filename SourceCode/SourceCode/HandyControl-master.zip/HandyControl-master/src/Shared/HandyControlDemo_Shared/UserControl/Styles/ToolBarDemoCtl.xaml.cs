﻿namespace HandyControlDemo.UserControl;

public partial class ToolBarDemoCtl
{
    public ToolBarDemoCtl()
    {
        InitializeComponent();
    }
}
