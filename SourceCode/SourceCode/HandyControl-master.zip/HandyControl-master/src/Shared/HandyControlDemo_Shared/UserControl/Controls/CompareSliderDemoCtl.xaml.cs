﻿
namespace HandyControlDemo.UserControl;

public partial class CompareSliderDemoCtl
{
    public CompareSliderDemoCtl()
    {
        InitializeComponent();
    }
}
