﻿
namespace HandyControlDemo.UserControl;

public partial class NativeTextBoxDemoCtl
{
    public NativeTextBoxDemoCtl()
    {
        InitializeComponent();
    }
}
