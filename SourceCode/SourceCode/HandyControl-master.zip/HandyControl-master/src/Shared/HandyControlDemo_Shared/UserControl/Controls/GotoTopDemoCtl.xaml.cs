﻿namespace HandyControlDemo.UserControl;

public partial class GotoTopDemoCtl
{
    public GotoTopDemoCtl()
    {
        InitializeComponent();
    }
}
