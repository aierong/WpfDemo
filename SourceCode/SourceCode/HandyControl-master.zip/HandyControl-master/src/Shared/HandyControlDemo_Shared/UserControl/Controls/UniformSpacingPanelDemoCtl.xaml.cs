﻿namespace HandyControlDemo.UserControl;

public partial class UniformSpacingPanelDemoCtl
{
    public UniformSpacingPanelDemoCtl()
    {
        InitializeComponent();
    }
}
