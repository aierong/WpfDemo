﻿namespace HandyControlDemo.UserControl;

public partial class ShieldDemoCtl
{
    public ShieldDemoCtl()
    {
        InitializeComponent();
    }
}
