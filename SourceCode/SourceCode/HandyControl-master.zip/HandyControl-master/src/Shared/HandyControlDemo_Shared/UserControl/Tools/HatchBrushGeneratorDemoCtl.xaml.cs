﻿namespace HandyControlDemo.UserControl;

public partial class HatchBrushGeneratorDemoCtl
{
    public HatchBrushGeneratorDemoCtl()
    {
        InitializeComponent();
    }
}
