﻿namespace HandyControlDemo.UserControl;

public partial class NativeDatePickerDemoCtl
{
    public NativeDatePickerDemoCtl()
    {
        InitializeComponent();
    }
}
