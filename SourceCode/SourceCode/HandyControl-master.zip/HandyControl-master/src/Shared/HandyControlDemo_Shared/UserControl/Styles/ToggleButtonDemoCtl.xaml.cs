﻿
namespace HandyControlDemo.UserControl;

public partial class ToggleButtonDemoCtl
{
    public ToggleButtonDemoCtl()
    {
        InitializeComponent();
    }
}
