﻿namespace HandyControlDemo.UserControl;

public partial class RelativePanelDemoCtl
{
    public RelativePanelDemoCtl()
    {
        InitializeComponent();
    }
}
