﻿namespace HandyControlDemo.UserControl;

public partial class GridDemoCtl : IFull
{
    public GridDemoCtl()
    {
        InitializeComponent();
    }
}
