﻿
namespace HandyControlDemo.UserControl;

public partial class RadioButtonDemoCtl
{
    public RadioButtonDemoCtl()
    {
        InitializeComponent();
    }
}
