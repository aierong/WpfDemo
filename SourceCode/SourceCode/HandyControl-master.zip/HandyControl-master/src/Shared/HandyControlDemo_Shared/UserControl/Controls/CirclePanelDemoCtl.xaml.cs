﻿namespace HandyControlDemo.UserControl;

public partial class CirclePanelDemoCtl
{
    public CirclePanelDemoCtl()
    {
        InitializeComponent();
    }
}
