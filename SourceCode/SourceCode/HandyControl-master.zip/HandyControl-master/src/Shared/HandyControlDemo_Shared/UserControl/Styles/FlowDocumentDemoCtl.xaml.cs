﻿namespace HandyControlDemo.UserControl;

public partial class FlowDocumentDemoCtl
{
    public FlowDocumentDemoCtl()
    {
        InitializeComponent();
    }
}
