﻿
namespace HandyControlDemo.UserControl;

public partial class NativeScrollViewerDemoCtl
{
    public NativeScrollViewerDemoCtl()
    {
        InitializeComponent();
    }
}
