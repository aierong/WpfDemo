﻿namespace HandyControlDemo.UserControl;

public partial class SideMenuDemoCtl
{
    public SideMenuDemoCtl()
    {
        InitializeComponent();
    }
}
