﻿namespace HandyControlDemo.Window;

public partial class NativeCommonWindow
{
    public NativeCommonWindow()
    {
        InitializeComponent();
    }
}
