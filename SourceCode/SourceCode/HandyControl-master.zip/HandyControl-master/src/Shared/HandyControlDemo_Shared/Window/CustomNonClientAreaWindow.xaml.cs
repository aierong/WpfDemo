﻿namespace HandyControlDemo.Window;

public partial class CustomNonClientAreaWindow
{
    public CustomNonClientAreaWindow()
    {
        InitializeComponent();
    }
}
