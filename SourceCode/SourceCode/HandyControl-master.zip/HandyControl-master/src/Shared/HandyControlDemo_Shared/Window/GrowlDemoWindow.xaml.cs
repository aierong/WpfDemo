﻿namespace HandyControlDemo.Window;

public partial class GrowlDemoWindow
{
    public GrowlDemoWindow()
    {
        InitializeComponent();
    }
}
