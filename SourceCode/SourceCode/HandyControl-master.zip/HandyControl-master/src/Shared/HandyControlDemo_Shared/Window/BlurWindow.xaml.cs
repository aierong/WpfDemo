﻿namespace HandyControlDemo.Window;

public partial class BlurWindow
{
    public BlurWindow()
    {
        InitializeComponent();
    }
}
