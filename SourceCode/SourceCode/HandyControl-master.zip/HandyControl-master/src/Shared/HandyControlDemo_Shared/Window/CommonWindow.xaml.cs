﻿namespace HandyControlDemo.Window;

public partial class CommonWindow
{
    public CommonWindow()
    {
        InitializeComponent();
    }
}
