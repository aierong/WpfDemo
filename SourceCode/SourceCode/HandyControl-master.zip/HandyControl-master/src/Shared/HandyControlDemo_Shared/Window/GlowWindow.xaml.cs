﻿namespace HandyControlDemo.Window;

public partial class GlowWindow
{
    public GlowWindow()
    {
        InitializeComponent();
    }
}
