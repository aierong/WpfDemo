﻿using System.Windows.Media;

namespace HandyControlDemo.Data;

public class GeometryItemModel
{
    public Geometry Data { get; set; }

    public string Key { get; set; }

    public bool Line { get; set; }
}
