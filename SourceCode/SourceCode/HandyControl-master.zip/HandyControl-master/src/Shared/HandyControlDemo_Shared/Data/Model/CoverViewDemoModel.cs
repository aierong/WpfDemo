﻿namespace HandyControlDemo.Data;

public class CoverViewDemoModel
{
    public string ImgPath { get; set; }

    public string BackgroundToken { get; set; }
}
