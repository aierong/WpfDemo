﻿namespace HandyControlDemo.Data;

public class CardModel
{
    public string Header { get; set; }

    public string Content { get; set; }

    public string Footer { get; set; }
}
