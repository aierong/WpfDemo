---
title: 欢迎来到HandyOrg
---

# 关于我们

HandyOrg的宗旨是为用户提供最简单的API。

我们一直期待有更多的同学加入。

# 入坑要求
 - 热爱编码
 - 接受目前Handy的代码风格，并尽量遵守
 - 项目名必须以Handy为前缀
 - 活着

# 参与讨论

[![qq-group](https://img.shields.io/badge/qq-714704041-red.svg)](//shang.qq.com/wpa/qunwpa?idkey=a571e5553c9d41e49c4f22f3a8b2865451497a795ff281fedf3285def247efc1) [![qq-group](https://img.shields.io/badge/qq-858784803-red.svg)](//shang.qq.com/wpa/qunwpa?idkey=5c18622a0f6ee07a6f33afa8cdb85b1f72ea50e878271dfcec919c76b55afee7)