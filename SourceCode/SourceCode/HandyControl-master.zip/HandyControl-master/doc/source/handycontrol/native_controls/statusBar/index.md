---
title: StatusBar 状态栏
---

# StatusBarBaseStyle

状态栏默认样式，不推荐直接使用，应该始终被其它样式以BasedOn的方式使用。