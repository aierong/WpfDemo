---
title: Calendar 日历
---

# CalendarBaseStyle

日历默认样式，不推荐直接使用，应该始终被其它样式以BasedOn的方式使用。

{% note info no-icon %}
用例：

{% code %}
<Calendar/>
{% endcode %}
![Calendar](https://raw.githubusercontent.com/HandyOrg/HandyOrgResource/master/HandyControl/Resources/Calendar.gif)
{% endnote %}