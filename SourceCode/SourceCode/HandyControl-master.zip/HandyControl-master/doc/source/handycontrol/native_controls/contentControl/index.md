---
title: ContentControl 内容控件
---

所有的`ContentControl`默认无法获得焦点