---
title: ToolTip 工具提示
---

# ToolTipBaseStyle

工具提示默认样式，不推荐直接使用，应该始终被其它样式以BasedOn的方式使用。