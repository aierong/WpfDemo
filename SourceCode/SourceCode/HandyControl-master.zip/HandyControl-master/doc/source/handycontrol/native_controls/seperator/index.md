---
title: Seperator 分隔符
---

# SeparatorBaseStyle

分隔符默认样式，不推荐直接使用，应该始终被其它样式以BasedOn的方式使用。