---
title: InfoType
---

{% note info no-icon %}
enum(int)
{% endnote %}

{% note info no-icon %}
消息类型
{% endnote %}

|成员名|值|说明|
|-|-|-|
| Success | 0 | 成功 |
| Info | 1 | 信息 |
| Warning | 2 | 警告 |
| Error | 3 | 错误 |
| Fatal | 4 | 严重 |
| Ask | 5 | 询问 |