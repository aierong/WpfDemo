---
title: 附加属性
---

附加属性源码在Controls / Attach文件夹中：

![Attach](https://raw.githubusercontent.com/HandyOrg/HandyOrgResource/master/HandyControl/Doc/attach/Attach.png)

以`Element`结尾的类，可以为所有的控件设置一些共有的属性，以`Attach`结尾的类，只能为一种控件设置相关的属性。