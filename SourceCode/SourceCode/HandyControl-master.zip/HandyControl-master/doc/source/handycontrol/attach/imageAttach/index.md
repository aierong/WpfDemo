---
title: ImageAttach Image专用
---

# 属性

| 名称 | 用途 |
|-|-|
| SourceFailed | 图片加载失败后显示的图片 |