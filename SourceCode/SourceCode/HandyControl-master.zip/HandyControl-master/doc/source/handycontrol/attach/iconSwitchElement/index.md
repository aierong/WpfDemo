---
title: IconSwitchElement 可切换图标的元素
---

{% note info no-icon %}
继承自 [IconElement](https://handyorg.github.io/handycontrol/attach/iconElement/)
{% endnote %}

# 属性

| 名称 | 用途 |
|-|-|
| GeometrySelected | 选中时的几何形状 |