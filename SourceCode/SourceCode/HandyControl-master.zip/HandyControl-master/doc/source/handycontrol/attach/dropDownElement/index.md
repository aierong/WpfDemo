---
title: DropDownElement 可下拉内容的元素
---

# 属性

| 名称 | 用途 |
|-|-|
| ConsistentWidth | 下拉内容是否和下拉框宽度一致 |