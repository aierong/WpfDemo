---
title: PasswordBoxAttach 密码框专用
---

该附加属性为hc内部密码框样式专用，不推荐直接使用。

# 属性

| 名称           | 用途     |
| -------------- | -------- |
| IsMonitoring   | 是否监测密码长度 |
| PasswordLength | 密码长度 |