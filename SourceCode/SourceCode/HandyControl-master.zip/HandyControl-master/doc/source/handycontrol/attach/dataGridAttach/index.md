---
title: DataGridAttach DataGrid专用
---

该附加属性为hc内部DataGrid样式专用，不推荐直接使用。

# 属性

| 名称 | 用途 |
|-|-|
| ApplyDefaultStyle | 是否应用默认样式 |
| TextColumnStyle | 文本列样式 |
| EditingTextColumnStyle | 编辑时文本列样式 |
| ComboBoxColumnStyle | 组合框列样式 |
| EditingComboBoxColumnStyle | 编辑时组合框列样式 |
| CheckBoxColumnStyle | 复选框列样式 |
| EditingCheckBoxColumnStyle | 编辑时复选框列样式 |
| ShowRowNumber | 是否显示行号 |