---
title: EdgeElement 具有边界内容的元素
---

# 属性

| 名称 | 用途 |
|-|-|
| LeftContent | 左侧边界内容 |
| TopContent | 顶部边界内容 |
| RightContent | 右侧边界内容 |
| BottomContent | 底部边界内容 |
| ShowEdgeContent | 是否显示边界内容 |