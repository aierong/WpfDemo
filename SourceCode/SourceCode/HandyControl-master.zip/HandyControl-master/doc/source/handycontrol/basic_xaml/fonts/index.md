---
title: 字体大小
---

| 名称 | 大小 | 用途 |
|-|-|
| LargeFontSize | 24 | 页面标题 |
| HeadFontSize | 20 | 功能标题 |
| SubHeadFontSize | 16 | 子功能标题 |
| TextFontSize | 12 | 文本 |

{% note info no-icon %}
用例：`FontSize="{StaticResource LargeFontSize}"`
{% endnote %}