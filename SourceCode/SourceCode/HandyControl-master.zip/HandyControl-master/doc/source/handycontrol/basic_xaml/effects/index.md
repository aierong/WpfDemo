---
title: 效果
---

# 阴影
目前只包含5个级别的阴影效果：

| 名称 | 半径 |
|-|-|
| EffectShadow1 | 5 |
| EffectShadow2 | 8 |
| EffectShadow3 | 14 |
| EffectShadow4 | 25 |
| EffectShadow5 | 35 |

{% note info no-icon %}
用例：`Effect="{StaticResource EffectShadow5}"`
{% endnote %}