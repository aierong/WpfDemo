---
title: ContextMenuButton 上下文菜单按钮
---

HC提供了两个上下文菜单按钮，分别是 `ContextMenuButton` 和 `ContextMenuToggleButton`，它们的使用方式和普通 `Button`、`ToggleButton` 一致，唯一的区别是提供了 `Menu` 属性，可用于实现点击按钮弹出上下文菜单的效果。