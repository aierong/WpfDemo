---
title: 扩展控件
---

HandyControl目前包含80余款扩展控件，正逐步增加。

{% note warning %}
各控件案例中所使用的资源均可在HC Demo中找到，请养成在vs中使用 `Ctrl+F` 组合键的习惯.
{% endnote %}