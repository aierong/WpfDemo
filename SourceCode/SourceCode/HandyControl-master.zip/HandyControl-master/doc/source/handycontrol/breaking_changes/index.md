---
title: 破坏性更新
---

出于各种原因，hc不总是会向后兼容，这将会带来破坏性更新。本文将记录您在更新到最新版本hc后，会遇到的各种不兼容问题。

## 3.0.0 

- `TitleElement.TitleAlignment` 重命名为 `TitleElement.TitlePlacement`
- `TagPanel` 已被 `TagContainer` 代替