﻿using System.Windows.Controls;

namespace UsingDialogService.Views
{
    /// <summary>
    /// Interaction logic for NotificationDialog
    /// </summary>
    public partial class NotificationDialog : UserControl
    {
        public NotificationDialog()
        {
            InitializeComponent();
        }
    }
}
