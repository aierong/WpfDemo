﻿using Prism.Mvvm;

namespace ModuleA.ViewModels
{
    public class ViewBViewModel : BindableBase
    {
        public ViewBViewModel()
        {

        }
    }
}
