﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PrismMetroSample.Shell.Configurations
{
   public class Settings
    {
        public static long WindowHandle;
    }
}
