﻿using System.Windows.Controls;

namespace PrismMetroSample.PatientModule.Views
{
    /// <summary>
    /// Interaction logic for PatientList
    /// </summary>
    public partial class PatientList : UserControl
    {
        public PatientList()
        {
            InitializeComponent();
        }
    }
}
