﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PrismMetroSample.Infrastructure.Constants
{
   public static class FlyoutNames
    {
        public static string PatientDetailFlyout = "PatientDetailFlyout";

        public static string SearchMedicineFlyout = "SearchMedicineFlyout";
    }
}
