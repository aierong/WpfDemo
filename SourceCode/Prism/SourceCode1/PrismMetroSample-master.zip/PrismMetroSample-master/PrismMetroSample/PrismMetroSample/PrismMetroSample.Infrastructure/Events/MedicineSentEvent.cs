﻿using Prism.Events;
using PrismMetroSample.Infrastructure.Models;

namespace PrismMetroSample.Infrastructure.Events
{
   public class MedicineSentEvent: PubSubEvent<Medicine>
    {

    }
}
