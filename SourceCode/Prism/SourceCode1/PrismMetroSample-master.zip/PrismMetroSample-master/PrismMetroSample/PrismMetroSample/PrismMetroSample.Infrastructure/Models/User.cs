﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PrismMetroSample.Infrastructure.Models
{
   public class User
    {
        public int Id { get; set; }

        public string LoginId { get; set; }

        public string PassWord { get; set; }
    }
}
