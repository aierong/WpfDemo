﻿namespace PrismMetroSample.Infrastructure.Services
{
    public interface IFlyoutView
    {
        string FlyoutName { get; }
    }
}
