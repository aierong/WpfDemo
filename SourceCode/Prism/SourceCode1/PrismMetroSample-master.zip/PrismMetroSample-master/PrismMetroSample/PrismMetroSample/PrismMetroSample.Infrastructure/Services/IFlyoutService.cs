﻿using PrismMetroSample.Infrastructure.Interceptor.HandlerAttributes;

namespace PrismMetroSample.Infrastructure.Services
{
   public interface IFlyoutService
    {
        void ShowFlyout(string flyoutName);
    }
}
