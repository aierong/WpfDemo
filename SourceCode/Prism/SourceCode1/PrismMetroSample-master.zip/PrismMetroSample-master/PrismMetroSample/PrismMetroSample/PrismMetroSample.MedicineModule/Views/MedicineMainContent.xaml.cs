﻿using System.Windows.Controls;

namespace PrismMetroSample.MedicineModule.Views
{
    /// <summary>
    /// Interaction logic for MedicineMainContent
    /// </summary>
    public partial class MedicineMainContent : UserControl
    {
        public MedicineMainContent()
        {
            InitializeComponent();
        }
    }
}
