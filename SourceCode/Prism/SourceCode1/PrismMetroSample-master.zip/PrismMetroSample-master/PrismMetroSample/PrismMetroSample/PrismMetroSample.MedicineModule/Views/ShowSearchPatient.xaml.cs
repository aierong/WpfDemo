﻿using System.Windows.Controls;

namespace PrismMetroSample.MedicineModule.Views
{
    /// <summary>
    /// Interaction logic for ShowSearchPatient
    /// </summary>
    public partial class ShowSearchPatient : StackPanel
    {
        public ShowSearchPatient()
        {
            InitializeComponent();
        }
    }
}
