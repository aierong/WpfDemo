﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// ScrollViewer.xaml 的交互逻辑
    /// </summary>
    public partial class ScrollViewer
    {
        public ScrollViewer()
        {
            InitializeComponent();
        }
    }
}
