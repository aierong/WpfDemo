﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// TimePicker.xaml 的交互逻辑
    /// </summary>
    public partial class TimePicker
    {
        public TimePicker()
        {
            InitializeComponent();
        }
    }
}
