﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// ToolBar.xaml 的交互逻辑
    /// </summary>
    public partial class ToolBar
    {
        public ToolBar()
        {
            InitializeComponent();
        }
    }
}
