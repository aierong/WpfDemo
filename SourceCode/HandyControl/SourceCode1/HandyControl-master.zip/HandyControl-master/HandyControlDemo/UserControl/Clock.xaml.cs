﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// clock.xaml 的交互逻辑
    /// </summary>
    public partial class Clock
    {
        public Clock()
        {
            InitializeComponent();
        }
    }
}
