﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Shield.xaml 的交互逻辑
    /// </summary>
    public partial class Shield
    {
        public Shield()
        {
            InitializeComponent();
        }
    }
}
