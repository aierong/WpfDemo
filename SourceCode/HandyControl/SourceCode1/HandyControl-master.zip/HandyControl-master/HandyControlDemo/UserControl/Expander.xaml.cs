﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Expander.xaml 的交互逻辑
    /// </summary>
    public partial class Expander
    {
        public Expander()
        {
            InitializeComponent();
        }
    }
}
