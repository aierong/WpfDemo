﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// OutlineText.xaml 的交互逻辑
    /// </summary>
    public partial class OutlineText
    {
        public OutlineText()
        {
            InitializeComponent();
        }
    }
}
