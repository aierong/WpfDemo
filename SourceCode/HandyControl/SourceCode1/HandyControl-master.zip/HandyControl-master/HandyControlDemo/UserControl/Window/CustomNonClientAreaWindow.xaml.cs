﻿namespace HandyControlDemo.UserControl.Window
{
    /// <summary>
    /// CustomNonClientAreaWindow.xaml 的交互逻辑
    /// </summary>
    public partial class CustomNonClientAreaWindow
    {
        public CustomNonClientAreaWindow()
        {
            InitializeComponent();
        }
    }
}
