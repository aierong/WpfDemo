﻿namespace HandyControlDemo.UserControl.Window
{
    /// <summary>
    /// NativeCommonWindow.xaml 的交互逻辑
    /// </summary>
    public partial class NativeCommonWindow
    {
        public NativeCommonWindow()
        {
            InitializeComponent();
        }
    }
}
