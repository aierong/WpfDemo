﻿namespace HandyControlDemo.UserControl.Window
{
    /// <summary>
    /// BlurWindow.xaml 的交互逻辑
    /// </summary>
    public partial class BlurWindow
    {
        public BlurWindow()
        {
            InitializeComponent();
        }
    }
}
