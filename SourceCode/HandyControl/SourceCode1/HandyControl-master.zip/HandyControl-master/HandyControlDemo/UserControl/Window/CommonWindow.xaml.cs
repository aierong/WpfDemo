﻿namespace HandyControlDemo.UserControl.Window
{
    /// <summary>
    /// CommonWindow.xaml 的交互逻辑
    /// </summary>
    public partial class CommonWindow
    {
        public CommonWindow()
        {
            InitializeComponent();
        }
    }
}
