﻿namespace HandyControlDemo.UserControl.Window
{
    /// <summary>
    /// AppSprite.xaml 的交互逻辑
    /// </summary>
    public partial class AppSprite
    {
        public AppSprite()
        {
            InitializeComponent();
        }
    }
}
