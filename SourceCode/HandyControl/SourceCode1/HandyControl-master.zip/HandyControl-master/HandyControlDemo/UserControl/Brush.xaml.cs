﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Brush.xaml 的交互逻辑
    /// </summary>
    public partial class Brush
    {
        public Brush()
        {
            InitializeComponent();
        }
    }
}
