﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Rate.xaml 的交互逻辑
    /// </summary>
    public partial class Rate
    {
        public Rate()
        {
            InitializeComponent();
        }
    }
}
