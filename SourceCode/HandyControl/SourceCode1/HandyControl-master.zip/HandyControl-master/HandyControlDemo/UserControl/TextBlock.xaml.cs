﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// TextBlock.xaml 的交互逻辑
    /// </summary>
    public partial class TextBlock
    {
        public TextBlock()
        {
            InitializeComponent();
        }
    }
}
