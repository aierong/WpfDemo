﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Calendar.xaml 的交互逻辑
    /// </summary>
    public partial class Calendar
    {
        public Calendar()
        {
            InitializeComponent();
        }
    }
}
