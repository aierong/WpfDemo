﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// ChatBox.xaml 的交互逻辑
    /// </summary>
    public partial class ChatBox
    {
        public ChatBox()
        {
            InitializeComponent();
        }
    }
}
