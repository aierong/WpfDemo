﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// CoverView.xaml 的交互逻辑
    /// </summary>
    public partial class CoverView
    {
        public CoverView()
        {
            InitializeComponent();
        }
    }
}
