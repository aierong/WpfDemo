﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// SearchBar.xaml 的交互逻辑
    /// </summary>
    public partial class SearchBar
    {
        public SearchBar()
        {
            InitializeComponent();
        }
    }
}
