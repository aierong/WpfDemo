﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// HatchBrushGenerator.xaml 的交互逻辑
    /// </summary>
    public partial class HatchBrushGenerator
    {
        public HatchBrushGenerator()
        {
            InitializeComponent();
        }
    }
}
