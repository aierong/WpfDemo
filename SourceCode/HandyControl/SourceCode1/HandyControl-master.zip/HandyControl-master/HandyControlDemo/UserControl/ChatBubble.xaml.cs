﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// ChatBubble.xaml 的交互逻辑
    /// </summary>
    public partial class ChatBubble
    {
        public ChatBubble()
        {
            InitializeComponent();
        }
    }
}
