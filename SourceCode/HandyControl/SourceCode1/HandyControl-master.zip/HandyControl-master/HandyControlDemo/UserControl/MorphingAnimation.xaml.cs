﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// MorphingAnimation.xaml 的交互逻辑
    /// </summary>
    public partial class MorphingAnimation
    {
        public MorphingAnimation()
        {
            InitializeComponent();
        }
    }
}
