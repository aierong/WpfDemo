﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Pagination.xaml 的交互逻辑
    /// </summary>
    public partial class Pagination
    {
        public Pagination()
        {
            InitializeComponent();
        }
    }
}
