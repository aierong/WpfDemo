﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// TreeView.xaml 的交互逻辑
    /// </summary>
    public partial class TreeView
    {
        public TreeView()
        {
            InitializeComponent();
        }
    }
}
