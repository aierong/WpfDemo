﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// WaterfallPanel.xaml 的交互逻辑
    /// </summary>
    public partial class WaterfallPanel
    {
        public WaterfallPanel()
        {
            InitializeComponent();
        }
    }
}
