﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// RelativePanel.xaml 的交互逻辑
    /// </summary>
    public partial class RelativePanel
    {
        public RelativePanel()
        {
            InitializeComponent();
        }
    }
}
