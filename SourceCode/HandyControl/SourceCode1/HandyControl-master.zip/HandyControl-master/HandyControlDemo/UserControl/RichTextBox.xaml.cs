﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// RichTextBox.xaml 的交互逻辑
    /// </summary>
    public partial class RichTextBox
    {
        public RichTextBox()
        {
            InitializeComponent();
        }
    }
}
