﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// FlipClock.xaml 的交互逻辑
    /// </summary>
    public partial class FlipClock
    {
        public FlipClock()
        {
            InitializeComponent();
        }
    }
}
