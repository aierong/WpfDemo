﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// AnimationPath.xaml 的交互逻辑
    /// </summary>
    public partial class AnimationPath
    {
        public AnimationPath()
        {
            InitializeComponent();
        }
    }
}
