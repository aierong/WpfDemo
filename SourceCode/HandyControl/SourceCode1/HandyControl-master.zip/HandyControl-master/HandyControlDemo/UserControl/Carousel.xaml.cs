﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Carousel.xaml 的交互逻辑
    /// </summary>
    public partial class Carousel
    {
        public Carousel()
        {
            InitializeComponent();
        }
    }
}
