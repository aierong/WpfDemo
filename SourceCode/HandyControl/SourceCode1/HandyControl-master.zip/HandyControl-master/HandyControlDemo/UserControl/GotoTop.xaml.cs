﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// GotoTop.xaml 的交互逻辑
    /// </summary>
    public partial class GotoTop
    {
        public GotoTop()
        {
            InitializeComponent();
        }
    }
}
