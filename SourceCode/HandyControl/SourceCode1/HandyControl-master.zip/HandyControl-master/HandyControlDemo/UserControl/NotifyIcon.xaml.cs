﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// NotifyIcon.xaml 的交互逻辑
    /// </summary>
    public partial class NotifyIcon
    {
        public NotifyIcon()
        {
            InitializeComponent();
        }
    }
}
