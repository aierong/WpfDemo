﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// GroupBox.xaml 的交互逻辑
    /// </summary>
    public partial class GroupBox
    {
        public GroupBox()
        {
            InitializeComponent();
        }
    }
}
