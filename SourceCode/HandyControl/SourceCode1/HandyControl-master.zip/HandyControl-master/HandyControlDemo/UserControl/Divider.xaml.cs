﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Divider.xaml 的交互逻辑
    /// </summary>
    public partial class Divider
    {
        public Divider()
        {
            InitializeComponent();
        }
    }
}
