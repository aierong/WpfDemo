﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Border.xaml 的交互逻辑
    /// </summary>
    public partial class Border
    {
        public Border()
        {
            InitializeComponent();
        }
    }
}
