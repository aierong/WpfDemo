﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Slider.xaml 的交互逻辑
    /// </summary>
    public partial class Slider
    {
        public Slider()
        {
            InitializeComponent();
        }
    }
}
