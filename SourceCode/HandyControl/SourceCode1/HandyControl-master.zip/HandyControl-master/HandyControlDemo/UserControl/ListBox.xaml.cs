﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// ListBox.xaml 的交互逻辑
    /// </summary>
    public partial class ListBox
    {
        public ListBox()
        {
            InitializeComponent();
        }
    }
}
