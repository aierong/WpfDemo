﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Menu.xaml 的交互逻辑
    /// </summary>
    public partial class Menu
    {
        public Menu()
        {
            InitializeComponent();
        }
    }
}
