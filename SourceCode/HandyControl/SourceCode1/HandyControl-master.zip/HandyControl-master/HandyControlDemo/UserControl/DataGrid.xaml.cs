﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// DataGrid.xaml 的交互逻辑
    /// </summary>
    public partial class DataGrid
    {
        public DataGrid()
        {
            InitializeComponent();
        }
    }
}
