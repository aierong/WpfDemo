﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Effects.xaml 的交互逻辑
    /// </summary>
    public partial class Effects
    {
        public Effects()
        {
            InitializeComponent();
        }
    }
}
