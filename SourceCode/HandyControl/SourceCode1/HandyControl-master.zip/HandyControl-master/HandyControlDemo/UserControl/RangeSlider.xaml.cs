﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// RangeSlider.xaml 的交互逻辑
    /// </summary>
    public partial class RangeSlider
    {
        public RangeSlider()
        {
            InitializeComponent();
        }
    }
}
