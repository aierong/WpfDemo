﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// TransitioningContentControl.xaml 的交互逻辑
    /// </summary>
    public partial class TransitioningContentControl
    {
        public TransitioningContentControl()
        {
            InitializeComponent();
        }
    }
}
