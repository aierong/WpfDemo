﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// SideMenu.xaml 的交互逻辑
    /// </summary>
    public partial class SideMenu
    {
        public SideMenu()
        {
            InitializeComponent();
        }
    }
}
