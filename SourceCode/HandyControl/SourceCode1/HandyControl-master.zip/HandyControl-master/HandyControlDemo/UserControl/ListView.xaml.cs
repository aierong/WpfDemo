﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// ListView.xaml 的交互逻辑
    /// </summary>
    public partial class ListView
    {
        public ListView()
        {
            InitializeComponent();
        }
    }
}
