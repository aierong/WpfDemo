﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Loading.xaml 的交互逻辑
    /// </summary>
    public partial class Loading
    {
        public Loading()
        {
            InitializeComponent();
        }
    }
}
