﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Card.xaml 的交互逻辑
    /// </summary>
    public partial class Card
    {
        public Card()
        {
            InitializeComponent();
        }
    }
}
