﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Label.xaml 的交互逻辑
    /// </summary>
    public partial class Label
    {
        public Label()
        {
            InitializeComponent();
        }
    }
}
