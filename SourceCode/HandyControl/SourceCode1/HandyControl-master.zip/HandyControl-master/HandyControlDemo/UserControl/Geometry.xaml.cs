﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Geometry.xaml 的交互逻辑
    /// </summary>
    public partial class Geometry
    {
        public Geometry()
        {
            InitializeComponent();
        }
    }
}
