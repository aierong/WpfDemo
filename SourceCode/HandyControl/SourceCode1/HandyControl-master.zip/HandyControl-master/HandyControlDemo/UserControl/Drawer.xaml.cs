﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Drawer.xaml 的交互逻辑
    /// </summary>
    public partial class Drawer
    {
        public Drawer()
        {
            InitializeComponent();
        }
    }
}
