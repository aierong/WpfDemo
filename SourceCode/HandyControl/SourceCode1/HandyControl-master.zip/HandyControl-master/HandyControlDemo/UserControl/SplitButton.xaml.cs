﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// SplitButton.xaml 的交互逻辑
    /// </summary>
    public partial class SplitButton
    {
        public SplitButton()
        {
            InitializeComponent();
        }
    }
}
