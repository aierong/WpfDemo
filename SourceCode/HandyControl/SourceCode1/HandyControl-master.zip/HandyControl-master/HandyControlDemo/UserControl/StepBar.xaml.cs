﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// StepBar.xaml 的交互逻辑
    /// </summary>
    public partial class StepBar
    {
        public StepBar()
        {
            InitializeComponent();
        }
    }
}
