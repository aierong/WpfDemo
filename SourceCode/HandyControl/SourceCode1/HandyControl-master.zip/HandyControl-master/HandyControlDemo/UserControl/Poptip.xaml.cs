﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Poptip.xaml 的交互逻辑
    /// </summary>
    public partial class Poptip
    {
        public Poptip()
        {
            InitializeComponent();
        }
    }
}
