﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// ElementGroup.xaml 的交互逻辑
    /// </summary>
    public partial class ElementGroup
    {
        public ElementGroup()
        {
            InitializeComponent();
        }
    }
}
