﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Notification.xaml 的交互逻辑
    /// </summary>
    public partial class Notification
    {
        public Notification()
        {
            InitializeComponent();
        }
    }
}
