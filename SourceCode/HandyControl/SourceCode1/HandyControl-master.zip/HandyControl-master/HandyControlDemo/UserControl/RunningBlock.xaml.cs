﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// RunningBlock.xaml 的交互逻辑
    /// </summary>
    public partial class RunningBlock
    {
        public RunningBlock()
        {
            InitializeComponent();
        }
    }
}
