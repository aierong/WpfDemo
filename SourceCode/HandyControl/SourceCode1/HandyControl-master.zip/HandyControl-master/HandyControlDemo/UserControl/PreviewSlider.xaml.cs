﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// PreviewSlider.xaml 的交互逻辑
    /// </summary>
    public partial class PreviewSlider
    {
        public PreviewSlider()
        {
            InitializeComponent();
        }
    }
}
