﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// TextBox.xaml 的交互逻辑
    /// </summary>
    public partial class TextBox
    {
        public TextBox()
        {
            InitializeComponent();
        }
    }
}
