﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// FlexPanel.xaml 的交互逻辑
    /// </summary>
    public partial class FlexPanel
    {
        public FlexPanel()
        {
            InitializeComponent();
        }
    }
}
