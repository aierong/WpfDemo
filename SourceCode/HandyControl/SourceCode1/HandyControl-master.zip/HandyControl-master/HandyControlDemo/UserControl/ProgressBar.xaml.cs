﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// ProgressBar.xaml 的交互逻辑
    /// </summary>
    public partial class ProgressBar
    {
        public ProgressBar()
        {
            InitializeComponent();
        }
    }
}
