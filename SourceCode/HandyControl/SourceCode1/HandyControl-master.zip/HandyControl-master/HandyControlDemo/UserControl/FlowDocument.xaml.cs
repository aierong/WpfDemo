﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// FlowDocument.xaml 的交互逻辑
    /// </summary>
    public partial class FlowDocument
    {
        public FlowDocument()
        {
            InitializeComponent();
        }
    }
}
