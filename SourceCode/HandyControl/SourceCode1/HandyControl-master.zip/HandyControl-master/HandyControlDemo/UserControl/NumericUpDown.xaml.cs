﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// NiumericUpDown.xaml 的交互逻辑
    /// </summary>
    public partial class NumericUpDown
    {
        public NumericUpDown()
        {
            InitializeComponent();
        }
    }
}
