﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// Sprite.xaml 的交互逻辑
    /// </summary>
    public partial class Sprite
    {
        public Sprite()
        {
            InitializeComponent();
        }
    }
}
