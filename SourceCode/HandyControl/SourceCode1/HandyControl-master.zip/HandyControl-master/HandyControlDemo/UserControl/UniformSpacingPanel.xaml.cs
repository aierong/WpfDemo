﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// UniformSpacingPanel.xaml 的交互逻辑
    /// </summary>
    public partial class UniformSpacingPanel
    {
        public UniformSpacingPanel()
        {
            InitializeComponent();
        }
    }
}
