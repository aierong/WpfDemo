﻿namespace HandyControlDemo.UserControl
{
    /// <summary>
    /// HoneycombPanel.xaml 的交互逻辑
    /// </summary>
    public partial class HoneycombPanel
    {
        public HoneycombPanel()
        {
            InitializeComponent();
        }
    }
}
