﻿namespace HandyControlDemo.Model
{
    public enum DemoType
    {
        Type1 = 1,
        Type2,
        Type3,
        Type4,
        Type5,
        Type6
    }
}
