﻿namespace HandyControlDemo.Model
{
    public enum DemoAnimation
    {
        None = 1,
        HorizontalMove,
        VerticalMove,
        Fade,
    }
}
