﻿using System.Windows.Media;

namespace HandyControlDemo.Model
{
    public class GeometryItemModel
    {
        public Geometry Data { get; set; }

        public string Key { get; set; }

        public bool Line { get; set; }
    }
}
