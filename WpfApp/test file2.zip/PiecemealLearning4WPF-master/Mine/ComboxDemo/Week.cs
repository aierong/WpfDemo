﻿namespace ComboxDemo
{
    public enum Week
    {
        First,
        Second,
        Third,
        Fourth,
        Last
    }
}
