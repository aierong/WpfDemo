﻿namespace ComboxDemo
{
    public enum AzimuthMapType
    {
        None = 0,
        Launch = 1,
        Receiving = 2,
        TwoWay = 3,
        EIRP = 4,
    }
}
