﻿namespace M3U8_Downloader
{
    public partial class FlowDocumentDemoCtl
    {
        public FlowDocumentDemoCtl()
        {
            InitializeComponent();
        }
    }
}
