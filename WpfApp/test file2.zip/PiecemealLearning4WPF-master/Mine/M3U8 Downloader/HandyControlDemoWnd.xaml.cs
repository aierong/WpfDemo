﻿namespace M3U8_Downloader
{
    /// <summary>
    /// HandyControlDemoWnd.xaml 的交互逻辑
    /// </summary>
    public partial class HandyControlDemoWnd
    {
        public HandyControlDemoWnd()
        {
            InitializeComponent();
        }
    }
}
