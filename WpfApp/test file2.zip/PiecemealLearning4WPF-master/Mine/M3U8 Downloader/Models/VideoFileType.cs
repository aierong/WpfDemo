﻿namespace M3U8_Downloader.Models
{
    /// <summary>
    /// 视频文件类型
    /// </summary>
    public enum VideoFileType
    {
        FLV = 0,
        MP4 = 1,
        MKV = 2,
        TS = 3
    }
}
