﻿using System.Windows;

namespace BV1H7411Z7dY
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
