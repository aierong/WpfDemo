﻿using System.Windows;

namespace BV1M54y1D7AG
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
