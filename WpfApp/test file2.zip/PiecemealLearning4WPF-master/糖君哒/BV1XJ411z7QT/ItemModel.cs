﻿namespace BV1XJ411z7QT
{
    public class ItemModel
    {
        public string Icon { get; set; }
        public string Title { get; set; }
        public string Text { get; set; }
    }
}
