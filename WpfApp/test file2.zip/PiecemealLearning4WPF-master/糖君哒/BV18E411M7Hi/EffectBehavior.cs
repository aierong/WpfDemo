﻿//using System.Windows.Interactivity;

namespace BV18E411M7Hi
{
    //public class EffectBehavior : Behavior<FrameworkElement>
    //{
    //}
}
