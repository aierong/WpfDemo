﻿using System.Windows;

namespace BV18E411M7Hi
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
