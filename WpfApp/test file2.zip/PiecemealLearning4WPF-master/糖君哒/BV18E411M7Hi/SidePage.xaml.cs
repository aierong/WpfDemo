﻿using System.Windows.Controls;

namespace BV18E411M7Hi
{
    /// <summary>
    /// SidePage.xaml 的交互逻辑
    /// </summary>
    public partial class SidePage : Page
    {
        public SidePage()
        {
            InitializeComponent();
        }
    }
}
