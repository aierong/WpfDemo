﻿using System.Windows;

namespace BV1u5411Y74a
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
