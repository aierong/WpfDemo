﻿using System.Windows;

namespace BV15V411U73V
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
