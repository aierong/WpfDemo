﻿using System.Windows.Controls;

namespace BV1uE411N7Bf.View
{
    /// <summary>
    /// Page3.xaml 的交互逻辑
    /// </summary>
    public partial class Page3 : Page
    {
        public Page3()
        {
            InitializeComponent();
        }
    }
}
