﻿namespace BV1uE411N7Bf.ViewModel
{
    public class Module
    {
        public string Name { get; set; }
    }
}
