﻿namespace BV1uJ411n7Zw.Entity
{
    public class UserModule
    {
        public string FilePath { get; set; }

        public string UserName { get; set; }

        public string Content { get; set; }

        public string SignTime { get; set; }
    }
}
