﻿using System.Windows;

namespace BV1qE411M7NU
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
