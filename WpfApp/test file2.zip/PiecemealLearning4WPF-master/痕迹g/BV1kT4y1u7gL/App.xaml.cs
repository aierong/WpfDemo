﻿using System.Windows;

namespace BV1kT4y1u7gL
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
