﻿using System.Windows;

namespace BV1mJ411F7zG
{
    /// <summary>
    /// P7_数据绑定.xaml 的交互逻辑
    /// </summary>
    public partial class P7_数据绑定 : Window
    {
        public P7_数据绑定()
        {
            InitializeComponent();
        }
    }
}
