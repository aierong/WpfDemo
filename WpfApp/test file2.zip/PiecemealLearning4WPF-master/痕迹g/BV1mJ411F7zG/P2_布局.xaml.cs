﻿using System.Windows;

namespace BV1mJ411F7zG
{
    /// <summary>
    /// P2_布局.xaml 的交互逻辑
    /// </summary>
    public partial class P2_布局 : Window
    {
        public P2_布局()
        {
            InitializeComponent();
        }
    }
}
