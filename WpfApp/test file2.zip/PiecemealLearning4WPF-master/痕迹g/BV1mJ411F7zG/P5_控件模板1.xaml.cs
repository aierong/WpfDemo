﻿using System.Windows;

namespace BV1mJ411F7zG
{
    /// <summary>
    /// P5_控件模板1.xaml 的交互逻辑
    /// </summary>
    public partial class P5_控件模板1 : Window
    {
        public P5_控件模板1()
        {
            InitializeComponent();
        }
    }
}
