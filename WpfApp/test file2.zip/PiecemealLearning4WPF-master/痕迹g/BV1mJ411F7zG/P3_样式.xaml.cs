﻿using System.Windows;

namespace BV1mJ411F7zG
{
    /// <summary>
    /// P3_样式.xaml 的交互逻辑
    /// </summary>
    public partial class P3_样式 : Window
    {
        public P3_样式()
        {
            InitializeComponent();
        }
    }
}
