﻿namespace BV1i7411y7VJ
{
    public class UserInstance
    {
        public string clientid { get; set; }
        public string username { get; set; }
        public string password { get; set; }
    }
}
