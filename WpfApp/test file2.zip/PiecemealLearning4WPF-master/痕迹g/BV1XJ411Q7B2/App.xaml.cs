﻿using System.Windows;

namespace BV1XJ411Q7B2
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
