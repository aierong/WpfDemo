﻿using System.Windows;

namespace BV1i7411y7VJ.Client
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
