﻿using System.Windows;

namespace BV1XJ41127Dp
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
