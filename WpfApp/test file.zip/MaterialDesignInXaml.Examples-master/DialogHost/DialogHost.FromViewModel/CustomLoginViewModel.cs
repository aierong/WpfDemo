﻿namespace DialogHost.FromViewModel
{
    //This derived type is simply a convenient way to apply a different 
    //data template based on type using the DataType
    public class CustomLoginViewModel : LoginViewModel
    { }
}