﻿namespace DialogHost.WithResult
{
    public enum Answer
    {
        None,
        Yes,
        No
    }
}