﻿using MaterialDesignThemes.Wpf;
using System;
using System.Windows.Controls;

namespace DialogHost.ChangingContent.MVVM.View
{
    /// <summary>
    /// Interaction logic for LoginControl.xaml
    /// </summary>
    public partial class LoginControl : UserControl
    {
        public LoginControl()
        {
            InitializeComponent();
        }
    }
}
