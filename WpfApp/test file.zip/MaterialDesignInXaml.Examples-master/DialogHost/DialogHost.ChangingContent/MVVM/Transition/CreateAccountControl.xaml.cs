﻿using MaterialDesignThemes.Wpf;
using System;
using System.Windows.Controls;

namespace DialogHost.ChangingContent.MVVM.Transition
{
    /// <summary>
    /// Interaction logic for CreateAccountControl.xaml
    /// </summary>
    public partial class CreateAccountControl : UserControl
    {
        public CreateAccountControl()
        {
            InitializeComponent();
        }
    }
}
