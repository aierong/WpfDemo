﻿using System.Windows.Controls;

namespace DialogHost.ChangingContent.MVVM.Transition
{
    /// <summary>
    /// Interaction logic for LoginControl.xaml
    /// </summary>
    public partial class LoginControl : UserControl
    {
        public LoginControl()
        {
            InitializeComponent();
        }
    }
}
