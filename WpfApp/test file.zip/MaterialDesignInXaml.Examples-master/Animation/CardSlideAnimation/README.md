﻿# CardSlideAnimation

CardSlideAnimation is an example project to animate a `MaterialDesignThemes.Wpf.Card` control with a code-behind `Storyboard`.

## Controls

|Type|Class name|
|----|----|
|Card|MaterialDesignThemes.Wpf.Card|

## Visual

![Animated GIF of project output](Assets/CardSlideAnimation.gif)