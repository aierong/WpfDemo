﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DemoApp.Demos.Airspace
{
    public enum AirspaceDemoMode
    {
        None,
        Clipping,
        Redirection,
        Custom
    }
}
