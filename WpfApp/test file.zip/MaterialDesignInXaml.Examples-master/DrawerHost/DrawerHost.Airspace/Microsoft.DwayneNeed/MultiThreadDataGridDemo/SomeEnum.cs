﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MultiThreadDataGridDemo
{
    public enum SomeEnum
    {
        Who,
        What,
        When,
        Where,
        Why,
        How
    }
}
