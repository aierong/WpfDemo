﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Threading;
using System.Runtime.InteropServices;
using System.ComponentModel;

namespace Microsoft.DwayneNeed.Extensions
{
    public static class DispatcherExtensions
    {
    }
}
