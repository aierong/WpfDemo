﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microsoft.DwayneNeed.Interop
{
    public enum DeviceContextCachePolicy
    {
        Global,
        WindowClass,
        Window
    }
}
