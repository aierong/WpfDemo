﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microsoft.DwayneNeed.Interop
{
    public class MouseActivateParameter
    {
        public bool Activate;
        public bool EatMessage;
        public bool HandleMessage;
    }
}
