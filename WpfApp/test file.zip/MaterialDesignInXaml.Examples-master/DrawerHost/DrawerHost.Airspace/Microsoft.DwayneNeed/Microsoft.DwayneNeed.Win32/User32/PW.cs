﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microsoft.DwayneNeed.Win32.User32
{
    public enum PW : int
    {
        DEFAULT = 0,
        CLIENTONLY           =0x00000001
    }
}
