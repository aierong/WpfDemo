﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microsoft.DwayneNeed.Win32.User32
{
    /// <summary>
    ///     Class field offsets for GetClassWord
    /// </summary>
    public enum GCW : int
    {
        ATOM = -32
    }
}
