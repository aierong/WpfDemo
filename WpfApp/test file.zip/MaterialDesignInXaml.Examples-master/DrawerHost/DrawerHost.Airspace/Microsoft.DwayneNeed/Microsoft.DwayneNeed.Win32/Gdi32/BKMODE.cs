﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microsoft.DwayneNeed.Win32.Gdi32
{
    public enum BKMODE : int
    {
        TRANSPARENT = 1,
        OPAQUE = 2
    }
}
