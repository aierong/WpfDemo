﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Microsoft.DwayneNeed.Win32.DwmApi
{
    public enum DWM_EC : int
    {
        DISABLECOMPOSITION = 0,
        ENABLECOMPOSITION = 1
    }
}
